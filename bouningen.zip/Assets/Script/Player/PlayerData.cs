﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable] public class PlayerData
{
    public float StartPositionX;
    public float StartPositionY;
    public string StageName;
}