﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Player_Carry : MonoBehaviour
{
    [SerializeField] UnityEvent OnEnterObject;
    [SerializeField] UnityEvent OnExitObject;
    private string Object = "unknown";
    [SerializeField] GameObject BOX;
    [SerializeField] GameObject AXE;
    [SerializeField] GameObject BOMB;
    private Box box;                      // Boxクラス
    private Axe axe;                      // Axeクラス
    private Bomb bomb;
    private float time = 0.0f;
    private int n = 0;
    private bool s_axe = false;
    [SerializeField] Player ps;

    private void start()
    {

    }

    private void Update()
    {
        if (s_axe)
        {
            ps.setHave(true);
            time += Time.deltaTime;
            n = (int)time;
            if (n == 3)
            {
                s_axe = false;
                time = 0.0f;
                n = 0;
            }
        }
    }

    // オブジェクトの持ち運び可能判定
    void OnTriggerStay2D(Collider2D other)
    {
        switch (other.gameObject.tag)
        {
            case "Box":
                OnEnterObject.Invoke();
                Object = "Box";
                break;
            case "Axe":
                OnEnterObject.Invoke();
                Object = "Axe";
                break;
            case "Bomb":
                OnEnterObject.Invoke();
                Object = "Bomb";
                break;
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        OnExitObject.Invoke();
    }

    public void HaveObject()
    {
        switch (Object)
        {
            case "Box":
                GameObject Box = BOX.transform.GetChild(0).gameObject;
                box = Box.GetComponent<Box>();
                box.BoxSwitch();
                break;
            case "Axe":
                GameObject Axe = AXE.transform.GetChild(0).gameObject;
                axe = Axe.GetComponent<Axe>();
                axe.AxeSwitch();
                break;
            case "Bomb":
                GameObject Bomb = BOMB.transform.GetChild(0).gameObject;
                bomb = Bomb.GetComponent<Bomb>();
                bomb.BombSwitch();
                break;
            default:
                break;
        }
    }

    public void PutObject()
    {
        switch (Object)
        {
            case "Box":
                box.BoxSwitch();
                break;
            case "Axe":
                if (!s_axe)
                {
                    axe.AxeSwitch();
                    ps.setHave(true);
                    s_axe = true;
                }
                break;
            case "Bomb":
                bomb.BombSwitch();
                break;
            default:
                break;
        }
    }

    public string getObject
    {
        get { return this.Object; }
    }

    public void setS_axe(bool s_axe)
    {
        this.s_axe = s_axe;
        time = 0.0f;
        n = 0;
    }
}
