﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BackTitle : MonoBehaviour
{
    void Update()
    {
        if (Input.GetKeyDown("space") || Input.GetKeyDown("joystick button 1")) title();
    }

    public void title()
    {
        SceneManager.LoadScene(0);
    }
}
