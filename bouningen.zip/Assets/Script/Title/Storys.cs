﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Storys : MonoBehaviour
{
    private int n = 0;
    [SerializeField] Sprite[] image;
    [SerializeField] Image im;
    [SerializeField] Text storyText;
    [SerializeField] string[] st;
    [SerializeField] int scene = 1;

    public void story()
    {
        if (n < image.Length)
        {
            storyText.text = string.Format(st[n], n);
            im.sprite = image[n];
            n++;
        }
        else
        {
            SceneManager.LoadScene(scene);
        }
    }
}
