﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class TitleCursor : MonoBehaviour
{
    [SerializeField] UnityEvent StartButton;
    [SerializeField] UnityEvent ContinueButton;
    [SerializeField] UnityEvent ManualButton;
    [SerializeField] GameObject[] Buttons;
    private int n = 0;
    private bool limiter = true;
    Vector3 pos;

    void Start()
    {
        pos = new Vector3(-70, -10, -1);
    }

    void Update()
    {
        float y = Input.GetAxisRaw("Vertical");

        if (y == 1)
        {
            if (limiter)
            {
                if (n == 0) n = 2;
                else if (n == 1) n = 0;
                else n = 1;
                gameObject.transform.parent = Buttons[n].gameObject.transform;
                transform.localPosition = pos;
                limiter = false;
            }
        }
        else if (y == -1)
        {
            if (limiter)
            {
                if (n == 0) n = 1;
                else if (n == 1) n = 2;
                else n = 0;
                gameObject.transform.parent = Buttons[n].gameObject.transform;
                transform.localPosition = pos;
                limiter = false;
            }
        }
        else limiter = true;

        if (Input.GetKeyDown(KeyCode.Z) || Input.GetKeyDown("joystick button 1"))
        {
            switch (n)
            {
                case 0:
                    StartButton.Invoke();
                    break;
                case 1:
                    ContinueButton.Invoke();
                    break;
                case 2:
                    ManualButton.Invoke();
                    break;
            }
        }
    }
}
