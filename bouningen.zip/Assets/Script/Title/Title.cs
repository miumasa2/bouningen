﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Title : MonoBehaviour
{
    [SerializeField] GameObject StartButton = default, ContinueButton = default, ManualButton = default;
    private string SaveFilePath,stage = "Stage1";
        
    void Start()
    {
        SaveFilePath = Application.dataPath + "/Savefile/savedata.json";
    }

    public void StartGame()
    {
        File.Delete(SaveFilePath);
        SceneManager.LoadScene("Opening");
    }

    public void ContinueGame()
    {
        LoadStage();
        SceneManager.LoadScene(stage);
    }

    public void StartManual()
    {
        SceneManager.LoadScene("Manual");
    }

    // セーブデータをロード
    private void LoadStage()
    {
        if (File.Exists(SaveFilePath))
        {
            // バイナリ形式でデシリアライズ
            BinaryFormatter bf = new BinaryFormatter();
            // 指定したパスのファイルストリームを開く
            FileStream file = File.Open(SaveFilePath, FileMode.Open);
            try
            {
                // 指定したファイルストリームをオブジェクトにデシリアライズ。
                PlayerData pd = (PlayerData)bf.Deserialize(file);
                // 読み込んだデータを反映。
                stage = pd.StageName;
            }
            finally
            {
                // ファイル操作には明示的な破棄が必要です。Closeを忘れないように。
                if (file != null)
                    file.Close();
                Debug.Log("ステージロード完了");
            }
        }
        else
            Debug.Log("no load file");
    }
}
