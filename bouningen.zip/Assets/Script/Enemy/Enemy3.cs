﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Enemy3 : MonoBehaviour
{
    [SerializeField] float dex;
    private int rev = 1;
    private Vector2 hitPos;

    void Start()
    {
        hitPos = Vector3.zero;
    }

    void Update()
    {
        transform.position += new Vector3(dex * Time.deltaTime * rev, 0, 0);
    }

    void OnCollisionStay2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("DtGround"))
        {
            foreach (var point in other.contacts)
            {
                if (hitPos != point.point) hitPos = point.point;
                else break;
            }

            var position = other.gameObject.GetComponent<Tilemap>().cellBounds.allPositionsWithin;
            var minPosition = 0;
            var allPosition = new List<Vector3>();

            foreach (var variable in position)
            {
                if (other.gameObject.GetComponent<Tilemap>().GetTile(variable) != null)
                {
                    allPosition.Add(variable);
                }
            }

            for (var i = 1; i < allPosition.Count; i++)
            {
                if ((Mathf.Abs(hitPos.x) - Mathf.Abs(allPosition[i].x)) + (Mathf.Abs(hitPos.y) - Mathf.Abs(allPosition[i].y)) <
                    (Mathf.Abs(hitPos.x) - Mathf.Abs(allPosition[minPosition].x)) + (Mathf.Abs(hitPos.y) - Mathf.Abs(allPosition[minPosition].y)))
                {
                    minPosition = i;
                }
            }

            var finalPosition = Vector3Int.RoundToInt(allPosition[minPosition]);

            var tiletmp = other.gameObject.GetComponent<Tilemap>().GetTile(finalPosition);

            if (tiletmp != null)
            {
                var map = other.gameObject.GetComponent<Tilemap>();
                map.SetTile(finalPosition, null);
            }
        }
        else if (!other.gameObject.CompareTag("Ground") && !other.gameObject.CompareTag("Player")) Destroy(other.gameObject);
    }
}
