﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField] float dex; // 速さ
    private int rev = -1;       // 向き
    private Player pr;
    private Bomb bm;
    private bool dash, bomb;
    private Vector2 pos;
    [SerializeField] Vector2 range1,range2;

    void Start()
    {
        GameObject Player = GameObject.Find("player");
        pr = Player.GetComponent<Player>();
        pos = transform.position;
    }

    void Update()
    {
        // dexの速さ分等速移動
        transform.position += new Vector3(dex * Time.deltaTime * rev, 0, 0);
        if(transform.position.x < range1.x || transform.position.x > range2.x || transform.position.y < range1.y || transform.position.y > range2.y)
            transform.position = pos;
    }

    void OnCollisionStay2D(Collision2D other)
    {
        // 何かに衝突した場合の反転処理
        if (!other.gameObject.CompareTag("Ground") && !other.gameObject.CompareTag("BeltConveyor"))
        {
            dash = pr.getDash;
            if (other.gameObject.CompareTag("Player") && dash)
                Destroy(gameObject);
            else
            {
                rev *= -1;          //進行方向の反転
                transform.localScale = new Vector3(transform.localScale.x * -1, transform.localScale.y, transform.localScale.z);
            }
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Bomb"))
        {
            GameObject Bomb = other.gameObject;
            bm = Bomb.GetComponent<Bomb>();
            bomb = bm.getBomb;
            if (bomb)
                Destroy(gameObject);
        }
    }
}
