﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Door : MonoBehaviour
{
    [SerializeField] string Stage;
    private int StageNum = 0;

    void Start()
    {
        if (Stage == null)
            StageNum = SceneManager.GetActiveScene().buildIndex;
        StageNum++;
    }

    void Update()
    {
        
    }

    void OnTriggerStay2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            float y = Input.GetAxisRaw("Vertical");

            if (Stage != null & y == 1)
                SceneManager.LoadScene(Stage);
            else if(y == 1)
                SceneManager.LoadScene(StageNum);
        }
    }
}
