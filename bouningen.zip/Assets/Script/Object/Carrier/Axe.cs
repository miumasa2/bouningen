﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Axe : MonoBehaviour
{
    [SerializeField] GameObject carrier;
    [SerializeField] Player ps;
    [SerializeField] Player_Carry pcs;
    [SerializeField] Rigidbody2D rb2d;
    [SerializeField] GameObject po;
    private bool h, shake = false;
    private BoxCollider2D[] bc2d;
    private PolygonCollider2D pc2d;
    [SerializeField] Animator animator;
    private int i = 0, f = 0, fc = 0;
    private float time = 0, x = 0;
    private RopeDirector rd;
    private TreeDirector td;

    private void Start()
    {
        bc2d = this.gameObject.GetComponents<BoxCollider2D>();
        pc2d = this.gameObject.GetComponent<PolygonCollider2D>();
        GameObject RopeDirector = GameObject.Find("Rope");
        rd = RopeDirector.GetComponent<RopeDirector>();
    }

    private void Update()
    {
        x = Input.GetAxisRaw("Horizontal");

        if (shake && x == 0)
        {
            switch (fc)
            {
                case 0:
                    if (f++ > 5)
                    {
                        this.gameObject.transform.localPosition = new Vector2(1.03f, 0.39f);
                        this.transform.rotation = Quaternion.Euler(0.0f, 0.0f, -21.5f);     // 0~
                        if (++f > 32) fc++;
                    }
                    break;
                case 1:
                    this.gameObject.transform.localPosition = new Vector2(0.63f, 1.27f);
                    this.transform.rotation = Quaternion.Euler(0.0f, 0.0f, 22.7f);      // 8~
                    if (++f > 57) fc++;
                    break;
                case 2:
                    this.gameObject.transform.localPosition = new Vector2(-0.86f, 1.54f);
                    this.transform.rotation = Quaternion.Euler(0.0f, 0.0f, 98.0f);      // 15~
                    if (++f > 107) fc++;
                    break;
                case 3:
                    this.gameObject.transform.localPosition = new Vector2(0.21f, 1.88f);
                    this.transform.rotation = Quaternion.Euler(0.0f, 0.0f, 46.0f);      // 38~
                    if (++f > 127) fc++;
                    break;
                case 4:
                    this.gameObject.transform.localPosition = new Vector2(1.33f, -0.08f);
                    this.transform.rotation = Quaternion.Euler(0.0f, 0.0f, -50.0f);     // 46~
                    if (++f > 152) fc++;
                    break;
                case 5:
                    this.gameObject.transform.localPosition = new Vector2(0.92f, -0.80f);
                    this.transform.rotation = Quaternion.Euler(0.0f, 0.0f, -83.2f);     // 53~
                    if (++f > 177) fc++;
                    break;
                case 6:
                    this.gameObject.transform.localPosition = new Vector2(1.33f, -0.08f);
                    this.transform.rotation = Quaternion.Euler(0.0f, 0.0f, -50.0f);     // 60
                    break;
            }
        }
    }

    public void AxeSwitch()
    {
        h = ps.getHave;
        if (h)
            Carry_Axe();
        else
            Shake_Axe();
    }

    void Carry_Axe()
    {
        animator.SetBool("axe", true);
        gameObject.transform.parent = carrier.gameObject.transform;
        GetComponent<Rigidbody2D>().isKinematic = true;
        this.gameObject.transform.localPosition = new Vector2(0.93f, 0.19f);     // 持たれたときの所定の位置
        this.gameObject.transform.localRotation = new Quaternion(0, 0, 14, -39);
        this.gameObject.transform.localScale = new Vector3(1, 1, 1);
        bc2d[0].enabled = false;
        bc2d[1].enabled = true;
        pc2d.enabled = true;
    }

    public void Shake_Axe()
    {
        animator.SetBool("atk", true);
        shake = true;
        rd.AttackDirect(shake);
        Coroutine coroutine = StartCoroutine("DelayAttackMethod", 1.0f);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (shake)
        {
            switch (other.gameObject.tag)
            {
                case "Rope":
                    GameObject RopeDirector = GameObject.Find("Rope");
                    rd = RopeDirector.GetComponent<RopeDirector>();
                    Debug.Log("ロープを切った");
                    shake = true;
                    rd.AttackDirect(shake);
                    rd.RopeDirect();
                    shake = false;
                    rd.AttackDirect(shake);
                    i++;
                    break;
                case "Tree":
                    GameObject TreeDirector = GameObject.Find("Tree");
                    td = TreeDirector.GetComponent<TreeDirector>();
                    Debug.Log("木を切った");
                    td.TreeDirect();
                    i++;
                    break;
                default:
                    break;
            }

            if (i == 3)
            {
                pcs.setS_axe(false);
                Destroy(this.gameObject);
                animator.SetBool("axe", false);
                i = 0;
                ps.setHave(false);
            }
        }
        else if (other.gameObject.CompareTag("Carrier"))
            this.gameObject.transform.SetSiblingIndex(0);
    }

    void OnCollisionStay2D(Collision2D other)
    {
        h = ps.getHave;
        if (h)      //　衝突後の停止判定
        {
            ps.speedManager(0);

            var objectSpeed = Vector2.Dot(rb2d.velocity, Vector2.right);

            if (objectSpeed < Mathf.Abs(3.0f))
            {
                rb2d.AddForce(Vector2.right * 50f * -po.transform.localScale.x, ForceMode2D.Force);
            }
        }
        else if (other.gameObject.CompareTag("Player"))
            this.gameObject.transform.SetSiblingIndex(0);
    }

    void OnCollisionExit2D(Collision2D other)
    {
        GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezeRotation;
        h = ps.getHave;
        if (h)
            ps.speedManager(1);
    }

    private IEnumerator DelayAttackMethod(float waitTime)
    {
        yield return new WaitForSeconds(waitTime);
        animator.SetBool("atk", false);
        shake = false;
        rd.AttackDirect(shake);
        this.gameObject.transform.localPosition = new Vector2(0.93f, 0.19f);
        this.gameObject.transform.localRotation = new Quaternion(0, 0, 14, -39);
        f = 0;
        fc = 0;
    }

    public bool getShake
    {
        get { return this.shake; }
    }
}
