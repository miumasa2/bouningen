﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxHang : MonoBehaviour
{
    private Box box;
    private GameObject Rope,Pbox;
    private Rigidbody2D brb2d;

    void Start()
    {
        GameObject Box = this.gameObject;
        box = Box.GetComponent<Box>();
        brb2d = GetComponent<Rigidbody2D>();
        Pbox = GameObject.Find("Box");
    }

    void Update()
    {
        Rope = this.gameObject.transform.parent.gameObject;
        if (Rope.CompareTag("AfterRope"))
            Dropping();
    }

    public void Dropping()
    {
        box.enabled = true;
        enabled = false;
        this.tag = "Box";
        brb2d.bodyType = RigidbodyType2D.Dynamic;
        gameObject.transform.parent = Pbox.gameObject.transform;
    }
}
