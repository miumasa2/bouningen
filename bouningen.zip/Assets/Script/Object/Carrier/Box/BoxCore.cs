﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxCore: MonoBehaviour
{
    private Box box;

    void Start()
    {
        GameObject Box = transform.parent.gameObject; ;
        box = Box.GetComponent<Box>();
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.gameObject.CompareTag("Box"))
            box.Dropper();
    }
}
