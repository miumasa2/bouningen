﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Box : MonoBehaviour
{
    [SerializeField] GameObject carrier;
    [SerializeField] Player ps;
    [SerializeField] Rigidbody2D rb2d;
    [SerializeField] GameObject po;
    private GameObject Pbox;
    private bool h,cb = false;
    [SerializeField] UnityEvent OnStopObject;
    [SerializeField] UnityEvent OnStartObject;
    [SerializeField] Animator animator;
    float x, y;
    private BoxHang bh;
    private Rigidbody2D brb2d;

    private void Start()
    {
        Pbox = GameObject.Find("Box");
        brb2d = GetComponent<Rigidbody2D>();
        if (this.gameObject.transform.parent.gameObject.CompareTag("Rope"))
        {
            brb2d.bodyType = RigidbodyType2D.Kinematic;
            brb2d.useFullKinematicContacts = true;
            GameObject BoxHang = this.gameObject;
            bh = BoxHang.GetComponent<BoxHang>();
            bh.enabled = true;
            enabled = false;
            this.tag = "Hanging";
        }
    }
    void Update()
    {
        if(cb == true)
        {
            this.gameObject.transform.localPosition = new Vector2(1.34f, 0.63f);
            //Vector2 G = new Vector2(0, 9.81f);
            //brb2d.AddForce(G);
            /*x = Mathf.Abs(this.gameObject.transform.position.x - carrier.transform.position.x);
            y = Mathf.Abs(this.gameObject.transform.position.y - carrier.transform.position.y);

            if(x > 1.34f || y > 0.63f)
                this.gameObject.transform.position = Vector2.MoveTowards(this.gameObject.transform.position, carrier.transform.position, 3);*/
        }
    }

    public void BoxSwitch()
    {
        h = ps.getHave;
        if (h)
            Carry_Box();
        else
            Put_Box();
    }

    void Carry_Box()
    {
        gameObject.transform.parent = carrier.gameObject.transform;
        // GetComponent<Rigidbody2D>().isKinematic = true;
        this.gameObject.transform.localPosition = new Vector2(1.34f,0.63f);     // 持たれたときの所定の位置
        cb = true;
        animator.SetBool("carry", true);
    }

    void Put_Box()
    {
        ps.speedManager(1);
        gameObject.transform.parent = Pbox.gameObject.transform;
        // GetComponent<Rigidbody2D>().isKinematic = false;
        cb = false;
        animator.SetBool("carry", false);
        this.gameObject.transform.SetSiblingIndex(0);
    }

    //　衝突後の停止判定
    void OnCollisionStay2D(Collision2D other)
    {
        h = ps.getHave;
        if (h && cb)
        {
            ps.speedManager(0);

            OnStopObject.Invoke();

            var objectSpeed = Vector2.Dot(rb2d.velocity, Vector2.right);

            if (objectSpeed < Mathf.Abs(3.0f))
            {
                rb2d.AddForce(Vector2.right * 50f * -po.transform.localScale.x, ForceMode2D.Force);
            }

            OnStartObject.Invoke();
        }

        if (other.gameObject.CompareTag("BeltConveyor"))
            GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezeRotation;
        else
            GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;
    }

    void OnCollisionExit2D(Collision2D other)
    {
        GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezeRotation;
        h = ps.getHave;
        if (h)
            ps.speedManager(1);
    }

    // 順番入れ替え
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Carrier"))
            this.gameObject.transform.SetSiblingIndex(0);
    }

    // 落とす判定
    public void Dropper()
    {
        h = ps.getHave;
        if (h && cb)
        {
            ps.setHave(false);
            Put_Box();
        }
    }
}
