﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class Bomb : MonoBehaviour
{
    private float totalTime;
    private CircleCollider2D[] cc2d;
    private HP hp;
    private Counter counter;
    private bool h, cb = false, bomb = false, On = false;
    [SerializeField] GameObject carrier;
    [SerializeField] Player ps;
    private GameObject Pbomb;
    [SerializeField] UnityEvent OnStopObject;
    [SerializeField] UnityEvent OnStartObject;
    [SerializeField] Animator animator;
    [SerializeField] Rigidbody2D rb2d;
    [SerializeField] GameObject po;
    private Vector2 pos;
    private SpriteRenderer sr;

    void Start()
    {
        cc2d = this.gameObject.GetComponents<CircleCollider2D>();
        GameObject HP = GameObject.Find("H");
        hp = HP.GetComponent<HP>();
        Pbomb = GameObject.Find("Bomb");
        GameObject Counter = this.gameObject.transform.GetChild(0).gameObject;
        counter = Counter.GetComponent<Counter>();
        pos = this.gameObject.transform.position;
        sr = this.gameObject.GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        if (cb == true)
        {
            this.gameObject.transform.localPosition = new Vector2(1.25f, 0.75f);
            On = true;
        }
        if (On)
            counter.Countdown();
    }

    public void Detonation(float totalTime)
    {
        this.totalTime = totalTime;
        if (totalTime < 0.5f)
        {
            bomb = true;
            cc2d[0].enabled = false;
            cc2d[1].enabled = true;
            if (totalTime < 0.3f)
            {
                Coroutine coroutine = StartCoroutine("DelayProductionMethod", 2.0f);
                sr.enabled = false;
                cc2d[1].enabled = false;
                On = false;
                counter.Repop();
            }
        }
    }

    public void BombSwitch()
    {
        h = ps.getHave;
        if (h)
            Carry_Bomb();
        else
            Put_Bomb();
    }

    void Carry_Bomb()
    {
        gameObject.transform.parent = carrier.gameObject.transform;
        this.gameObject.transform.localPosition = new Vector2(1.05f, 0.55f);     // 持たれたときの所定の位置
        this.gameObject.transform.localRotation = new Quaternion(0, 0, 0, 0);
        GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezeRotation;
        cb = true;
        animator.SetBool("carry", true);
    }

    void Put_Bomb()
    {
        ps.speedManager(1);
        gameObject.transform.parent = Pbomb.gameObject.transform;
        GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.None;
        cb = false;
        animator.SetBool("carry", false);
        this.gameObject.transform.SetSiblingIndex(0);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player") && bomb)
            hp.ollDamage();
        if (other.gameObject.CompareTag("Carrier"))
            this.gameObject.transform.SetSiblingIndex(0);
    }

    void OnCollisionStay2D(Collision2D other)
    {
        h = ps.getHave;
        if (h && cb)
        {
            ps.speedManager(0);

            OnStopObject.Invoke();

            var objectSpeed = Vector2.Dot(rb2d.velocity, Vector2.right);

            if (objectSpeed < Mathf.Abs(3.0f))
            {
                rb2d.AddForce(Vector2.right * 50f * -po.transform.localScale.x, ForceMode2D.Force);
            }

            OnStartObject.Invoke();
        }
    }

    void OnCollisionExit2D(Collision2D other)
    {
        h = ps.getHave;
        if (h)
            ps.speedManager(1);
    }

    private IEnumerator DelayProductionMethod(float waitTime)
    {
        yield return new WaitForSeconds(waitTime);
        bomb = false;
        cc2d[0].enabled = true;
        sr.enabled = true;
        GetComponent<Rigidbody2D>().constraints = RigidbodyConstraints2D.FreezeAll;
        this.gameObject.transform.position = pos;
        this.gameObject.transform.rotation = Quaternion.Euler(0.0f, 0.0f, 0.0f);
    }

    public bool getBomb
    {
        get { return this.bomb; }
    }
}
