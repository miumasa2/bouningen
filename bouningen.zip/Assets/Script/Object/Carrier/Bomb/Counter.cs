﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Counter: MonoBehaviour
{
    [SerializeField] Sprite cs0, cs1, cs2, cs3, cs4, cs5, cs6, cs7, cs8, cs9, cs10;
    private SpriteRenderer csr;
    private float totalTime,x;
    private int seconds;
    private Bomb bomb;
    private GameObject pr;

    void Start()
    {
        totalTime = 11.0f;
        csr = this.gameObject.GetComponent<SpriteRenderer>();
        GameObject Bomb = this.gameObject.transform.parent.gameObject;
        bomb = Bomb.GetComponent<Bomb>();
    }

    void Update()
    {
        pr = transform.parent.gameObject;
        x = pr.transform.localScale.x;
        pr = transform.root.gameObject;
        if (pr.transform.localScale == new Vector3 (-1, 1, 1))
            this.transform.localScale = new Vector3(-1 * x, 1, 1);
        else
            this.transform.localScale = new Vector3(1 * x, 1, 1);
    }

    public void Countdown()
    {
        totalTime -= Time.deltaTime;
        seconds = (int)totalTime;
        switch (seconds)
        {
            case 10:
                csr.sprite = cs10;
                break;
            case 9:
                csr.sprite = cs9;
                break;
            case 8:
                csr.sprite = cs8;
                break;
            case 7:
                csr.sprite = cs7;
                break;
            case 6:
                csr.sprite = cs6;
                break;
            case 5:
                csr.sprite = cs5;
                break;
            case 4:
                csr.sprite = cs4;
                break;
            case 3:
                csr.sprite = cs3;
                break;
            case 2:
                csr.sprite = cs2;
                break;
            case 1:
                csr.sprite = cs1;
                break;
            case 0:
                csr.sprite = cs0;
                bomb.Detonation(totalTime);
                break;
        }
    }

    public void Repop()
    {
        csr.sprite = null;
        totalTime = 11.0f;
    }
}
