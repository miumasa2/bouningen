﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class SwitchCore : MonoBehaviour
{
    [SerializeField] UnityEvent OnSwitch;
    [SerializeField] UnityEvent OffSwitch;
    [SerializeField] GameObject WallCore;       // WallCoreオブジェクト
    [SerializeField] Animator animator;         // Animatorを取得
    private WallCore wc;                        // WallCoreクラス
    private string[] tag = new string[10];
    private bool enter = false, same = false;
    private int n;

    void Start()
    {
        wc = WallCore.GetComponent<WallCore>();     // WallCoreの中にあるWallCoreを取得して変数に格納
    }

    void Update()
    {
        if (enter) wc.SlideUP();
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.gameObject.CompareTag("Ground"))
        {
            if (!enter)
            {
                n = 0;
                enter = true;
                tag[n] = other.transform.tag;
                animator.SetBool("Switch", true);
                OnSwitch.Invoke();
            }
            else
            {
                same = false;
                for (int i = 0; i < n; i++)
                    if (tag[i] == other.transform.tag)
                    {
                        same = true;
                        break;
                    }
                if (!same)
                {
                    n++;
                    tag[n] = other.transform.tag;
                }
            }
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (tag[0] == other.transform.tag)
        {
            if (n != 0)
            {
                for (int i = 0; i == n; i++) tag[i] = tag[i + 1];
                n--;

                if (n == 0)
                {
                    enter = false;
                    wc.SlideDOWN();
                    animator.SetBool("Switch", false);
                    OffSwitch.Invoke();
                }
            }
            else
            {
                enter = false;
                wc.SlideDOWN();
                animator.SetBool("Switch", false);
                OffSwitch.Invoke();
            }
        }
    }
}
