﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Switch: MonoBehaviour
{
    private Vector3 pos;
    public bool enter { get; set; }
    private float m,l;

    void Start()
    {
        pos = transform.localPosition;
        l = pos.y;
        m = 0.27f;
    }

    void Update()
    {
        if (enter)
        {
            if (l - m < transform.localPosition.y) pos.y -= 0.01f;
        }
        else
        {
            if (l > transform.localPosition.y) pos.y += 0.01f;
        }
        transform.localPosition = pos;
    }
}
