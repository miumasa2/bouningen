﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SavePoint : MonoBehaviour
{
    private Vector2 pos;
    private string SaveFilePath;

    private void Start()
    {
        SaveFilePath = Application.dataPath + "/Savefile/savedata.json";
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            pos = other.gameObject.transform.position;
            OnSaveNewData();
        }
    }

    private void OnSaveNewData()
    {
        // セーブデータ作成
        PlayerData pd = CreateSaveData();
        // バイナリ形式でシリアル化
        BinaryFormatter bf = new BinaryFormatter();
        // 指定したパスにファイルを作成
        FileStream file = File.Create(SaveFilePath);
        // Closeが確実に呼ばれるように例外処理を用いる
        try
        {
            // 指定したオブジェクトを上で作成したストリームにシリアル化する
            bf.Serialize(file, pd);
        }
        finally
        {
            // ファイル操作には明示的な破棄が必要です。Closeを忘れないように。
            if (file != null)
                file.Close();
            Debug.Log("セーブ完了");
        }
    }

    // 入力された情報をもとにセーブデータを作成
    private PlayerData CreateSaveData()
    {
        PlayerData pd = new PlayerData();
        pd.StartPositionX = pos.x;
        pd.StartPositionY = pos.y - 1.0f;
        pd.StageName = SceneManager.GetActiveScene().name;
        return pd;
    }
}
